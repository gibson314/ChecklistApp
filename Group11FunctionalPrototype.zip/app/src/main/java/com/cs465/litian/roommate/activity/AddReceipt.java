package com.cs465.litian.roommate.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.cs465.litian.roommate.R;

/**
 * Created by litia on 11/17/2016.
 */

public class AddReceipt extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_receipt);
    }
}
