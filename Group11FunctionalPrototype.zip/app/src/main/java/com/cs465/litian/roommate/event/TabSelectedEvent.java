package com.cs465.litian.roommate.event;

/**
 * Created by litia on 11/10/2016.
 */

public class TabSelectedEvent {
    public int position;
    public TabSelectedEvent(int position) {
        this.position = position;
    }
}