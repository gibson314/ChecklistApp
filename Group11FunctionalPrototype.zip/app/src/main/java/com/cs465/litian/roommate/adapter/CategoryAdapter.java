package com.cs465.litian.roommate.adapter;

import android.view.View;

/**
 * Created by litia on 11/13/2016.
 */

public abstract class CategoryAdapter {

}
